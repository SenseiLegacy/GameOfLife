using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell : MonoBehaviour
{
    
    public bool cellAlive;
    public int neighboursAlive;
    SpriteRenderer spriteRenderer;


    private Color colorAlive = Color.cyan;
     private Color colorTargetInitial = Color.blue;
    private Color colorTarget;
    private Color lerpedColor;
    private int cellDeadFrames = 0;

    public bool cellStable = false;

    public void UpdateStatus()
    {
         spriteRenderer ??= GetComponent<SpriteRenderer>();

        if (cellAlive == true)
        {
            spriteRenderer.material.color=colorAlive;
            spriteRenderer.enabled=true;
            cellDeadFrames = 0;
        }
        
        if (cellAlive == false)
        {   
            colorTarget = colorTargetInitial;
            cellDeadFrames++;
            if (cellDeadFrames > 7)
            {
                colorTarget = Color.black;
            }
            lerpedColor = Color.Lerp(colorAlive, colorTarget, cellDeadFrames*0.1f);
            spriteRenderer.material.color = lerpedColor;
            if(cellDeadFrames >10)
            {
                spriteRenderer.enabled=false;
            }
        }
        
        if (cellDeadFrames <3 || cellDeadFrames >10)
        {
            cellStable=true;
        }
        else 
        {
            cellStable=false;
        }
        
        
        
       
       // spriteRenderer.enabled=cellAlive;

    }

    
}

using System;
using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using Unity.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Analytics;
using UnityEngine.Android;
using UnityEngine.Assertions.Must;
using UnityEngine.UIElements;
using TMPro;


public class cells : MonoBehaviour
{
    public TMP_Text stabilGenerationText;
    public GameObject cellPrefab;
    public  int percentageAlive; 

    [Header("Grid")]
    public int gridSizex;
    public int gridSizey;

    Cell[,] grid;

    [Header("Stability")]
    public float stabilityProcent;
    public int cellsStable;

    public int generation = 0;
    public int generationStabil;
  
    

    void Start()
    {
        Application.targetFrameRate=60;
        grid = new Cell[gridSizex, gridSizey];
  
        for (int i = 0; i < gridSizex ; i++)
        {
            for(int j= 0; j < gridSizey; j++)
            {
                Vector2 newPos = new Vector2(i,j);
                var newCell = Instantiate(cellPrefab,newPos,Quaternion.identity);

                grid[i,j]=newCell.GetComponent<Cell>();
                if (UnityEngine.Random.Range(0,100)< percentageAlive)
                    {
                        grid[i,j].cellAlive = true;
                    }
                    grid[i,j].UpdateStatus();
            }     
        }             
    }




    void Update()
    {
        generation++;
        cellsStable=0;
        for (int i = 0; i<gridSizex; i++)
        {
            for (int j = 0; j<gridSizey; j++)
            {
                grid[i,j].UpdateStatus();
                grid[i,j].neighboursAlive = NeighboursAlive(i,j);
               
                if (grid[i,j].cellStable)
                {
                    cellsStable++;
                }
                
            }
        }

        for (int i = 0; i<gridSizex; i++)
        {
            for (int j = 0; j<gridSizey; j++)
            {
                grid[i,j].cellAlive = IsAlive(grid[i,j].neighboursAlive, grid[i,j].cellAlive);
                     
                
            }                  
        }


        if (Input.GetMouseButton(1))
        {
            Vector2 mousePos = Input.mousePosition;
            Vector2 pos = Camera.main.ScreenToWorldPoint(mousePos);
            int x = Mathf.FloorToInt(pos.x);
            int y =Mathf.FloorToInt(pos.y);
            grid[x, y].cellAlive=true;

        }

        stabilityProcent=100*cellsStable/(gridSizex*gridSizey);
        if (stabilityProcent==100 && generation!=1 && generationStabil==0)
        {
            generationStabil=generation;
            stabilGenerationText.text=("Generation: " + generationStabil.ToString());
        }
        
    }

        public int NeighboursAlive(int _x, int _y) 
        {
           
            int neighboursAlive=0;
            for (int i = -1; i <=1; i++)
            {
                for (int j = -1; j <=1 ; j++)
                {
                  
                    int x = _x + i;
                    int y = _y + j;

                    if (i == 0 && j == 0)
                    {
                        continue;
                    }

                    if(x < 0 || x > gridSizex-1 || y < 0 || y > gridSizey-1)
                    {
                        continue;
                    }
                        
                    if(grid[x, y].cellAlive == true)
                    {
                        neighboursAlive++;
                    }                                 
                }
            }
            return neighboursAlive;
        }



        public bool IsAlive(int _neighbourdsAlive, bool _cellAlive)
        {   
            int neighboursAlive = _neighbourdsAlive;
            bool cellAlive = _cellAlive;
            
            if(cellAlive==true && neighboursAlive == 2)
            {
                return cellAlive;
            }
            if (neighboursAlive == 3)
            {
                cellAlive=true;
            }
            else 
            {
                cellAlive=false;
            }

            return cellAlive;
        }


        public void KillAllCells()
        {
        for (int i = 0; i < gridSizex ; i++)
        {
            for(int j= 0; j < gridSizey; j++)
            {
                grid[i,j].cellAlive = false;
            } 
        }     
        }


        public void SpawnRandom()
        {
        for (int i = 0; i < gridSizex ; i++)
        {
            for(int j= 0; j < gridSizey; j++)
            {
            if (UnityEngine.Random.Range(0,100)< percentageAlive)
                {
                    grid[i,j].cellAlive = true;
                }
            } 
        }     
        }



}
